# Contributing to Focus Clock

:+1::tada: First off, thanks for taking the time to contribute! :tada::+1:

The following is a set of guidelines for contributing to _FC_. These are mostly guidelines, not rules. Use your best judgment, and feel free to propose changes to this document in a pull request.
